// Love Meter Animation and Interaction Logic

// Heart animation functions
function createHeartExplosion(event) {
    const x = event.clientX;
    const y = event.clientY;

    // Create multiple hearts for explosion effect
    for (let i = 0; i < 15; i++) {
        createExplosionHeart(x, y);
    }
}

function createExplosionHeart(x, y) {
    const heart = document.createElement('div');
    heart.innerHTML = '❤️';
    heart.classList.add('exploding-heart');

    // Random position around click
    const randomOffsetX = (Math.random() - 0.5) * 150;
    const randomOffsetY = (Math.random() - 0.5) * 150;

    heart.style.left = (x + randomOffsetX) + 'px';
    heart.style.top = (y + randomOffsetY) + 'px';
    heart.style.fontSize = Math.random() * 20 + 10 + 'px';
    heart.style.opacity = '1';
    heart.style.position = 'fixed';
    heart.style.zIndex = '9999';
    heart.style.pointerEvents = 'none';
    heart.style.transition = 'all 1s ease-out';

    document.body.appendChild(heart);

    // Animate heart
    setTimeout(() => {
        heart.style.transform = `translate(${randomOffsetX * 2}px, ${randomOffsetY * 2 - 100}px) rotate(${Math.random() * 360}deg)`;
        heart.style.opacity = '0';
    }, 10);

    // Remove heart
    setTimeout(() => {
        heart.remove();
    }, 1000);
}

// Button and link hover effects
function addHoverEffects() {
    const buttons = document.querySelectorAll('.cta-button, .download-button, .social-button');

    buttons.forEach(button => {
        button.addEventListener('mouseenter', () => {
            button.style.transform = 'translateY(-3px)';
            button.style.boxShadow = '0 7px 15px rgba(255, 77, 141, 0.4)';
        });

        button.addEventListener('mouseleave', () => {
            button.style.transform = 'translateY(0)';
            button.style.boxShadow = '0 4px 10px rgba(255, 77, 141, 0.3)';
        });
    });
}

// Cursor spotlight effect
function addCursorSpotlight() {
    const heroSection = document.getElementById('hero');

    if (heroSection) {
        heroSection.addEventListener('mousemove', (e) => {
            const x = e.clientX / window.innerWidth;
            const y = e.clientY / heroSection.offsetHeight;

            heroSection.style.background = `radial-gradient(circle at ${x * 100}% ${y * 100}%, rgba(255, 105, 180, 0.3), rgba(147, 51, 234, 0.5)), #FF4D8D`;
        });

        heroSection.addEventListener('mouseleave', () => {
            heroSection.style.background = '';
        });
    }
}

// Simple confetti effect (alternative to the module)
function triggerConfetti() {
    for (let i = 0; i < 100; i++) {
        createConfettiParticle();
    }
}

function createConfettiParticle() {
    const colors = ['#FF4D8D', '#8E2DE2', '#4A00E0', '#6a11cb', '#2575fc'];
    const confetti = document.createElement('div');
    confetti.style.position = 'fixed';
    confetti.style.width = Math.random() * 10 + 5 + 'px';
    confetti.style.height = Math.random() * 6 + 3 + 'px';
    confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
    confetti.style.left = Math.random() * window.innerWidth + 'px';
    confetti.style.top = '-20px';
    confetti.style.opacity = '1';
    confetti.style.borderRadius = Math.random() > 0.5 ? '50%' : '0';
    confetti.style.zIndex = '9999';
    confetti.style.pointerEvents = 'none';
    document.body.appendChild(confetti);

    const duration = Math.random() * 3 + 2;
    const rotation = Math.random() * 360;

    confetti.animate([
        {
            transform: `translateY(0) rotate(0deg)`,
            opacity: 1
        },
        {
            transform: `translateY(${window.innerHeight}px) rotate(${rotation}deg)`,
            opacity: 0
        }
    ], {
        duration: duration * 1000,
        easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)'
    }).onfinish = () => confetti.remove();
}

// Initialize all animations and effects
document.addEventListener('DOMContentLoaded', function() {
    // Add click effects
    document.addEventListener('click', createHeartExplosion);

    // Add hover effects
    addHoverEffects();

    // Add cursor spotlight
    addCursorSpotlight();

    // Add confetti to CTA button
    const ctaButton = document.querySelector('.cta-button');
    if (ctaButton) {
        ctaButton.addEventListener('click', triggerConfetti);
    }

    // Animate features on scroll
    const features = document.querySelectorAll('.feature');

    // Add animation classes
    features.forEach((feature, index) => {
        feature.style.opacity = '0';
        feature.style.transform = 'translateY(20px)';
        feature.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        feature.style.transitionDelay = `${index * 0.2}s`;
    });

    // Function to check if element is in viewport
    function isInViewport(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top <= (window.innerHeight || document.documentElement.clientHeight) * 0.8 &&
            rect.bottom >= 0
        );
    }

    // Animate elements when in viewport
    function animateOnScroll() {
        features.forEach(feature => {
            if (isInViewport(feature)) {
                feature.style.opacity = '1';
                feature.style.transform = 'translateY(0)';
            }
        });
    }

    // Initial check and add scroll listener
    animateOnScroll();
    window.addEventListener('scroll', animateOnScroll);
});
